const { chromium } = require('playwright');

(async () => {
  console.log('Starting browser test...');
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  // Capture console errors
  const errors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') {
      errors.push(msg.text());
    }
  });
  
  page.on('pageerror', err => {
    errors.push(err.message);
  });
  
  try {
    // Test homepage
    console.log('Testing homepage...');
    await page.goto('https://shm351o3nsgo.space.minimax.io/', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3000);
    
    // Check key elements
    const title = await page.title();
    console.log('Page title:', title);
    
    // Check for main sections
    const quranSection = await page.locator('text=اقْرَأْ').first().isVisible();
    console.log('Quran verses visible:', quranSection);
    
    const aboutSection = await page.locator('text=من نحن').first().isVisible();
    console.log('About section visible:', aboutSection);
    
    const joinSection = await page.locator('text=كيف تنضم').first().isVisible();
    console.log('Join section visible:', joinSection);
    
    // Test colleges page
    console.log('\nTesting colleges page...');
    await page.goto('https://shm351o3nsgo.space.minimax.io/colleges', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3000);
    const collegesContent = await page.content();
    console.log('Colleges page has كليات:', collegesContent.includes('كليات') || collegesContent.includes('الكليات'));
    
    // Test certificate page
    console.log('\nTesting certificate page...');
    await page.goto('https://shm351o3nsgo.space.minimax.io/certificate', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3000);
    const certContent = await page.content();
    console.log('Certificate page has شهادة:', certContent.includes('شهادة'));
    
    // Test register page
    console.log('\nTesting register page...');
    await page.goto('https://shm351o3nsgo.space.minimax.io/register', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3000);
    const registerContent = await page.content();
    console.log('Register page has تسجيل:', registerContent.includes('تسجيل'));
    
    // Test library page
    console.log('\nTesting library page...');
    await page.goto('https://shm351o3nsgo.space.minimax.io/library', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3000);
    const libraryContent = await page.content();
    console.log('Library page has مكتبة:', libraryContent.includes('مكتبة') || libraryContent.includes('المكتبة'));
    
    // Test members page
    console.log('\nTesting members page...');
    await page.goto('https://shm351o3nsgo.space.minimax.io/members', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3000);
    const membersContent = await page.content();
    console.log('Members page has أعضاء:', membersContent.includes('أعضاء'));
    
    // Test contact page
    console.log('\nTesting contact page...');
    await page.goto('https://shm351o3nsgo.space.minimax.io/contact', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3000);
    const contactContent = await page.content();
    console.log('Contact page has تواصل:', contactContent.includes('تواصل'));
    
    // Test admin page
    console.log('\nTesting admin page...');
    await page.goto('https://shm351o3nsgo.space.minimax.io/admin', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3000);
    const adminContent = await page.content();
    console.log('Admin page has بوابة:', adminContent.includes('بوابة'));
    
    // Check for errors
    console.log('\n=== Error Summary ===');
    if (errors.length > 0) {
      console.log('Console errors found:', errors.length);
      errors.forEach(e => console.log('  - ' + e.substring(0, 100)));
    } else {
      console.log('No console errors!');
    }
    
    console.log('\n=== All tests completed! ===');
  } catch (err) {
    console.error('Test failed:', err.message);
  } finally {
    await browser.close();
  }
})();
