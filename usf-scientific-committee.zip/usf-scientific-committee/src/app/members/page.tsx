'use client';

import { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { colleges } from '@/data/channels';
import { storage, Member } from '@/data/types';

export default function MembersPage() {
  const [members, setMembers] = useState<Member[]>([]);
  const [filterCollege, setFilterCollege] = useState('');
  const [filterLevel, setFilterLevel] = useState('');

  useEffect(() => {
    setMembers(storage.getMembers());
  }, []);

  const filteredMembers = members.filter(member => {
    if (filterCollege && member.college !== filterCollege) return false;
    if (filterLevel && member.level !== filterLevel) return false;
    return true;
  });

  const groupedMembers = filteredMembers.reduce((acc, member) => {
    const key = `${member.college}-${member.level}`;
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(member);
    return acc;
  }, {} as Record<string, Member[]>);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 lg:pt-32 pb-12 bg-gradient-to-br from-blue-900 via-blue-800 to-emerald-900">
        <div className="container mx-auto px-4 text-center">
          <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <svg className="w-12 h-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <h1 className="text-3xl lg:text-5xl font-bold text-white mb-4">أعضاء اللجنة العلمية</h1>
          <p className="text-blue-200 text-lg">تعرف على أعضاء فريق العمل</p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-blue-600">{members.length}</div>
              <p className="text-slate-600">إجمالي الأعضاء</p>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-emerald-600">
                {new Set(members.map(m => m.college)).size}
              </div>
              <p className="text-slate-600">عدد الكليات</p>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-amber-600">
                {members.filter(m => m.gender === 'ذكر').length}
              </div>
              <p className="text-slate-600">أعضاء ذكور</p>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-pink-600">
                {members.filter(m => m.gender === 'أنثى').length}
              </div>
              <p className="text-slate-600">أعضاء إناث</p>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-6 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <select
              value={filterCollege}
              onChange={(e) => setFilterCollege(e.target.value)}
              className="flex-1 px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
            >
              <option value="">جميع الكليات</option>
              {colleges.map(col => (
                <option key={col} value={col}>{col}</option>
              ))}
            </select>
            <select
              value={filterLevel}
              onChange={(e) => setFilterLevel(e.target.value)}
              className="flex-1 px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
            >
              <option value="">جميع المستويات</option>
              <option value="أول">المستوى الأول</option>
              <option value="ثاني">المستوى الثاني</option>
              <option value="ثالث">المستوى الثالث</option>
              <option value="رابع">المستوى الرابع</option>
              <option value="خامس">المستوى الخامس</option>
            </select>
          </div>
        </div>
      </section>

      {/* Members Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {Object.keys(groupedMembers).length === 0 ? (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-12 h-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-slate-700 mb-2">لا يوجد أعضاء</h3>
              <p className="text-slate-500">لم يتم تسجيل أي أعضاء بعد</p>
            </div>
          ) : (
            <div className="space-y-8">
              {Object.entries(groupedMembers).map(([key, groupMembers]) => {
                const [college, level] = key.split('-');
                return (
                  <div key={key} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div className="bg-gradient-to-r from-blue-600 to-emerald-500 px-6 py-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center text-white">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                          </div>
                          <div>
                            <h3 className="text-white font-bold text-lg">{college}</h3>
                            <p className="text-white/80 text-sm">المستوى {level}</p>
                          </div>
                        </div>
                        <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm">
                          {groupMembers.length} عضو
                        </span>
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {groupMembers.map((member) => (
                          <div
                            key={member.id}
                            className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-xl p-4 hover:shadow-lg transition-all"
                          >
                            <div className="flex items-center gap-3 mb-3">
                              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                                member.gender === 'ذكر' 
                                  ? 'bg-blue-100 text-blue-600' 
                                  : 'bg-pink-100 text-pink-600'
                              }`}>
                                {member.gender === 'ذكر' ? (
                                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                  </svg>
                                ) : (
                                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                  </svg>
                                )}
                              </div>
                              <div className="flex-1">
                                <h4 className="font-bold text-slate-800">{member.fullName}</h4>
                                {member.role && (
                                  <p className="text-emerald-600 text-sm">{member.role}</p>
                                )}
                              </div>
                            </div>
                            
                            <div className="space-y-2 text-sm">
                              <div className="flex items-center gap-2 text-slate-600">
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                </svg>
                                <span>{member.college}</span>
                              </div>
                              <div className="flex items-center gap-2 text-slate-600">
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                </svg>
                                <span>المستوى {member.level}</span>
                              </div>
                              {member.phone && member.gender === 'ذكر' && (
                                <div className="flex items-center gap-2 text-slate-600">
                                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                  </svg>
                                  <span dir="ltr">{member.phone}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
