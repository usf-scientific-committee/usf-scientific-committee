'use client';

import { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { colleges, levels, specialties } from '@/data/channels';
import { storage, LibraryItem } from '@/data/types';

export default function LibraryPage() {
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [library, setLibrary] = useState<LibraryItem[]>([]);
  const [filterCollege, setFilterCollege] = useState('');
  const [filterLevel, setFilterLevel] = useState('');
  const [filterSubject, setFilterSubject] = useState('');
  
  const [formData, setFormData] = useState({
    college: '',
    level: '',
    term: '',
    subject: '',
    doctor: '',
    fileType: '',
    specialty: '',
    uploaderName: ''
  });

  useEffect(() => {
    setLibrary(storage.getLibrary());
  }, []);

  const filteredLibrary = library.filter(item => {
    if (filterCollege && item.college !== filterCollege) return false;
    if (filterLevel && item.level !== filterLevel) return false;
    if (filterSubject && !item.subject.toLowerCase().includes(filterSubject.toLowerCase())) return false;
    return true;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newItem: LibraryItem = {
      id: Date.now().toString(),
      ...formData,
      fileName: formData.subject,
      fileUrl: '#',
      status: 'approved',
      uploadDate: new Date().toISOString()
    };

    storage.addToLibrary(newItem);
    setLibrary(storage.getLibrary());
    setShowSuccess(true);
    setShowUploadForm(false);
    setFormData({
      college: '',
      level: '',
      term: '',
      subject: '',
      doctor: '',
      fileType: '',
      specialty: '',
      uploaderName: ''
    });

    setTimeout(() => setShowSuccess(false), 5000);
  };

  const getFileIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pdf':
        return (
          <svg className="w-8 h-8 text-red-500" fill="currentColor" viewBox="0 0 24 24">
            <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6zM6 20V4h7v5h5v11H6z"/>
            <path d="M8 12h8v2H8zm0 4h8v2H8z"/>
          </svg>
        );
      case 'ملخص':
        return (
          <svg className="w-8 h-8 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        );
      default:
        return (
          <svg className="w-8 h-8 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation />
      
      {/* Success Message */}
      {showSuccess && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-emerald-500 text-white px-8 py-4 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span className="font-bold">شكراً لك على مشاركتك لرفع المحتوى العلمي</span>
          <span className="text-emerald-200">كتب الله أجرك وجعلك من طلبة العلم والمعرفة</span>
        </div>
      )}

      {/* Hero Section */}
      <section className="pt-24 lg:pt-32 pb-12 bg-gradient-to-br from-blue-900 via-blue-800 to-emerald-900">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
              <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
          </div>
          <h1 className="text-3xl lg:text-5xl font-bold text-white mb-4">المكتبة الرقمية</h1>
          <p className="text-blue-200 text-lg">شارك المحتوى العلمي مع زملائك الطلاب</p>
        </div>
      </section>

      {/* Upload Section */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-800">المحتوى العلمي المتاح</h2>
              <p className="text-slate-500">{filteredLibrary.length} ملف متاح</p>
            </div>
            <button
              onClick={() => setShowUploadForm(!showUploadForm)}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:shadow-xl transition-all"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              <span>رفع محتوى جديد</span>
            </button>
          </div>
        </div>
      </section>

      {/* Upload Form */}
      {showUploadForm && (
        <section className="py-8 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-slate-800 mb-6 text-center">رفع محتوى علمي جديد</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">الكلية *</label>
                    <select
                      required
                      value={formData.college}
                      onChange={(e) => setFormData({...formData, college: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    >
                      <option value="">اختر الكلية</option>
                      {colleges.map(col => (
                        <option key={col} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">المستوى *</label>
                    <select
                      required
                      value={formData.level}
                      onChange={(e) => setFormData({...formData, level: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    >
                      <option value="">اختر المستوى</option>
                      {levels.map(level => (
                        <option key={level} value={level}>المستوى {level}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">الترم</label>
                    <select
                      value={formData.term}
                      onChange={(e) => setFormData({...formData, term: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    >
                      <option value="">اختر الترم</option>
                      <option value="الترم الأول">الترم الأول</option>
                      <option value="الترم الثاني">الترم الثاني</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">اسم المادة *</label>
                    <input
                      type="text"
                      required
                      value={formData.subject}
                      onChange={(e) => setFormData({...formData, subject: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      placeholder="مثال: التشريح"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">اسم الدكتور *</label>
                    <input
                      type="text"
                      required
                      value={formData.doctor}
                      onChange={(e) => setFormData({...formData, doctor: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      placeholder="اسم الدكتور"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">نوع الملف *</label>
                    <select
                      required
                      value={formData.fileType}
                      onChange={(e) => setFormData({...formData, fileType: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    >
                      <option value="">اختر نوع الملف</option>
                      <option value="ملخص">ملخص</option>
                      <option value="PDF">PDF</option>
                      <option value="شرح">شرح</option>
                      <option value="أسئلة">أسئلة</option>
                      <option value="أخرى">أخرى</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">التخصص</label>
                  <input
                    type="text"
                    value={formData.specialty}
                    onChange={(e) => setFormData({...formData, specialty: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    placeholder="التخصص (اختياري)"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">اسم الطالب المشارك</label>
                  <input
                    type="text"
                    value={formData.uploaderName}
                    onChange={(e) => setFormData({...formData, uploaderName: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    placeholder="اسمك (اختياري)"
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:shadow-xl transition-all"
                  >
                    رفع الملف
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowUploadForm(false)}
                    className="px-6 py-3 rounded-xl font-bold border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            </div>
          </div>
        </section>
      )}

      {/* Filters */}
      <section className="py-6 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <input
                type="text"
                placeholder="ابحث باسم المادة..."
                value={filterSubject}
                onChange={(e) => setFilterSubject(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
              />
            </div>
            <select
              value={filterCollege}
              onChange={(e) => setFilterCollege(e.target.value)}
              className="px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
            >
              <option value="">جميع الكليات</option>
              {colleges.map(col => (
                <option key={col} value={col}>{col}</option>
              ))}
            </select>
            <select
              value={filterLevel}
              onChange={(e) => setFilterLevel(e.target.value)}
              className="px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
            >
              <option value="">جميع المستويات</option>
              {levels.map(level => (
                <option key={level} value={level}>المستوى {level}</option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* Library Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {filteredLibrary.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-12 h-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-slate-700 mb-2">لا توجد ملفات</h3>
              <p className="text-slate-500">كن أول من يرفع محتوى علمي</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredLibrary.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all group"
                >
                  <div className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-emerald-100 rounded-xl flex items-center justify-center">
                        {getFileIcon(item.fileType)}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold text-slate-800 text-lg">{item.subject}</h3>
                        <p className="text-slate-500 text-sm">{item.doctor}</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">
                        {item.college}
                      </span>
                      <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-xs font-medium">
                        المستوى {item.level}
                      </span>
                      <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-xs font-medium">
                        {item.fileType}
                      </span>
                    </div>

                    {item.uploaderName && (
                      <p className="text-slate-500 text-sm mb-4">
                        شاركه: {item.uploaderName}
                      </p>
                    )}

                    <button className="w-full bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-4 py-3 rounded-xl font-bold hover:shadow-lg transition-all flex items-center justify-center gap-2">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      <span>تنزيل الملف</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
