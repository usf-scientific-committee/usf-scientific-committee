'use client';

import { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { storage, Member, LibraryItem, Admin, CertificateRequest } from '@/data/types';
import { colleges, levels } from '@/data/channels';

type TabType = 'members' | 'library' | 'admins' | 'certificates';

export default function AdminPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<TabType>('members');
  const [members, setMembers] = useState<Member[]>([]);
  const [pendingItems, setPendingItems] = useState<LibraryItem[]>([]);
  const [library, setLibrary] = useState<LibraryItem[]>([]);
  const [certificates, setCertificates] = useState<CertificateRequest[]>([]);
  const [showAddAdmin, setShowAddAdmin] = useState(false);
  const [newAdmin, setNewAdmin] = useState({ fullName: '', email: '', password: '', college: '' });

  useEffect(() => {
    // Check if already logged in
    const savedAdmin = localStorage.getItem('usf_admin_session');
    if (savedAdmin) {
      setAdmin(JSON.parse(savedAdmin));
      setIsLoggedIn(true);
    }
    loadData();
  }, []);

  const loadData = () => {
    setMembers(storage.getMembers());
    setPendingItems(storage.getPending());
    setLibrary(storage.getLibrary());
    setCertificates(storage.getCertificates());
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const loggedInAdmin = storage.loginAdmin(email, password);
    if (loggedInAdmin) {
      setAdmin(loggedInAdmin);
      setIsLoggedIn(true);
      localStorage.setItem('usf_admin_session', JSON.stringify(loggedInAdmin));
    } else {
      setLoginError('البريد الإلكتروني أو كلمة المرور غير صحيحة');
    }
  };

  const handleLogout = () => {
    setAdmin(null);
    setIsLoggedIn(false);
    localStorage.removeItem('usf_admin_session');
    setEmail('');
    setPassword('');
  };

  const deleteMember = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا العضو؟')) {
      storage.deleteMember(id);
      loadData();
    }
  };

  const approveItem = (id: string) => {
    storage.approveItem(id);
    loadData();
  };

  const rejectItem = (id: string) => {
    if (confirm('هل أنت متأكد من رفض هذا المحتوى؟')) {
      storage.rejectItem(id);
      loadData();
    }
  };

  const deleteLibraryItem = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا المحتوى؟')) {
      const updated = library.filter(item => item.id !== id);
      storage.saveLibrary(updated);
      loadData();
    }
  };

  const addNewAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    const newAdminData: Admin = {
      id: Date.now().toString(),
      ...newAdmin,
      createdAt: new Date().toISOString()
    };
    storage.addAdmin(newAdminData);
    setShowAddAdmin(false);
    setNewAdmin({ fullName: '', email: '', password: '', college: '' });
    alert('تم إضافة المشرف بنجاح');
  };

  const exportToExcel = (data: Member[], filename: string) => {
    const headers = ['الاسم', 'الكلية', 'المستوى', 'الجنس', 'الهاتف', 'العمل', 'ملاحظات', 'تاريخ التسجيل'];
    const rows = data.map(m => [
      m.fullName,
      m.college,
      m.level,
      m.gender,
      m.phone || '',
      m.role || '',
      m.notes || '',
      new Date(m.registrationDate).toLocaleDateString('ar-SA')
    ]);

    let csv = '\uFEFF'; // BOM for UTF-8
    csv += headers.join(',') + '\n';
    rows.forEach(row => {
      csv += row.map(cell => `"${cell}"`).join(',') + '\n';
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}.csv`;
    link.click();
  };

  const exportLibraryToExcel = (data: LibraryItem[], filename: string) => {
    const headers = ['الكلية', 'المستوى', 'المادة', 'الدكتور', 'نوع الملف', 'التخصص', 'المشارك', 'الحالة', 'التاريخ'];
    const rows = data.map(item => [
      item.college,
      item.level,
      item.subject,
      item.doctor,
      item.fileType,
      item.specialty,
      item.uploaderName || '',
      item.status === 'approved' ? 'معتمد' : item.status === 'pending' ? 'معلق' : 'مرفوض',
      new Date(item.uploadDate).toLocaleDateString('ar-SA')
    ]);

    let csv = '\uFEFF';
    csv += headers.join(',') + '\n';
    rows.forEach(row => {
      csv += row.map(cell => `"${cell}"`).join(',') + '\n';
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}.csv`;
    link.click();
  };

  // Login Screen
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-emerald-500 px-8 py-6 text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h1 className="text-2xl font-bold text-white">بوابة المشرفين</h1>
              <p className="text-white/80">تسجيل الدخول إلى لوحة التحكم</p>
            </div>

            <form onSubmit={handleLogin} className="p-8 space-y-6">
              {loginError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl">
                  {loginError}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                  placeholder="أدخل البريد الإلكتروني"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  كلمة المرور
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                  placeholder="أدخل كلمة المرور"
                  dir="ltr"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:shadow-xl transition-all"
              >
                تسجيل الدخول
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // Admin Dashboard
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 lg:pt-32 pb-8 bg-gradient-to-br from-blue-900 via-blue-800 to-emerald-900">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2">لوحة التحكم</h1>
              <p className="text-blue-200">مرحباً {admin?.fullName}</p>
            </div>
            <button
              onClick={handleLogout}
              className="bg-white/20 text-white px-6 py-3 rounded-xl font-medium hover:bg-white/30 transition-colors flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-6 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 text-white">
              <div className="text-3xl font-bold">{members.length}</div>
              <div className="text-blue-100">الأعضاء المسجلين</div>
            </div>
            <div className="bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl p-4 text-white">
              <div className="text-3xl font-bold">{pendingItems.length}</div>
              <div className="text-amber-100">في انتظار المراجعة</div>
            </div>
            <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl p-4 text-white">
              <div className="text-3xl font-bold">{library.length}</div>
              <div className="text-emerald-100">المحتوى المعتمد</div>
            </div>
            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-4 text-white">
              <div className="text-3xl font-bold">{certificates.length}</div>
              <div className="text-purple-100">طلبات الشهادات</div>
            </div>
            <div className="bg-gradient-to-br from-rose-500 to-rose-600 rounded-xl p-4 text-white">
              <div className="text-3xl font-bold">1</div>
              <div className="text-rose-100">المشرفين</div>
            </div>
          </div>
        </div>
      </section>

      {/* Tabs */}
      <section className="py-6 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveTab('members')}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'members'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-slate-700 hover:bg-slate-100'
              }`}
            >
              إدارة الأعضاء
            </button>
            <button
              onClick={() => setActiveTab('library')}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'library'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-slate-700 hover:bg-slate-100'
              }`}
            >
              مراجعة المحتوى
            </button>
            <button
              onClick={() => setActiveTab('certificates')}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'certificates'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-slate-700 hover:bg-slate-100'
              }`}
            >
              طلبات الشهادات
            </button>
            <button
              onClick={() => setActiveTab('admins')}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'admins'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-slate-700 hover:bg-slate-100'
              }`}
            >
              إدارة المشرفين
            </button>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          {/* Members Tab */}
          {activeTab === 'members' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-800">الأعضاء المسجلين</h2>
                <button
                  onClick={() => exportToExcel(members, 'أعضاء_اللجنة_العلمية')}
                  className="bg-emerald-500 text-white px-6 py-3 rounded-xl font-medium hover:bg-emerald-600 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span>تصدير Excel</span>
                </button>
              </div>

              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-slate-100">
                      <tr>
                        <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الاسم</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الكلية</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">المستوى</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الجنس</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الهاتف</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">العمل</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {members.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="px-4 py-8 text-center text-slate-500">
                            لا يوجد أعضاء مسجلين
                          </td>
                        </tr>
                      ) : (
                        members.map((member) => (
                          <tr key={member.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3 font-medium text-slate-800">{member.fullName}</td>
                            <td className="px-4 py-3 text-slate-600">{member.college}</td>
                            <td className="px-4 py-3 text-slate-600">{member.level}</td>
                            <td className="px-4 py-3">
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                member.gender === 'ذكر' ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'
                              }`}>
                                {member.gender}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-slate-600" dir="ltr">{member.phone || '-'}</td>
                            <td className="px-4 py-3 text-slate-600">{member.role || '-'}</td>
                            <td className="px-4 py-3">
                              <button
                                onClick={() => deleteMember(member.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Library Tab */}
          {activeTab === 'library' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-800">مراجعة المحتوى العلمي</h2>
                <button
                  onClick={() => exportLibraryToExcel(library, 'المحتوى_العلمي')}
                  className="bg-emerald-500 text-white px-6 py-3 rounded-xl font-medium hover:bg-emerald-600 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span>تصدير تقرير</span>
                </button>
              </div>

              {/* Pending Items */}
              {pendingItems.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-xl font-bold text-amber-600 mb-4">في انتظار المراجعة ({pendingItems.length})</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {pendingItems.map((item) => (
                      <div key={item.id} className="bg-white rounded-xl shadow-lg p-4 border border-amber-200">
                        <h4 className="font-bold text-slate-800 mb-2">{item.subject}</h4>
                        <p className="text-sm text-slate-600 mb-2">{item.college} - المستوى {item.level}</p>
                        <p className="text-sm text-slate-500 mb-4">د. {item.doctor}</p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => approveItem(item.id)}
                            className="flex-1 bg-emerald-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-emerald-600"
                          >
                            قبول
                          </button>
                          <button
                            onClick={() => rejectItem(item.id)}
                            className="flex-1 bg-red-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-600"
                          >
                            رفض
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Approved Items */}
              <div>
                <h3 className="text-xl font-bold text-emerald-600 mb-4">المحتوى المعتمد ({library.length})</h3>
                <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-slate-100">
                        <tr>
                          <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">المادة</th>
                          <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الكلية</th>
                          <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">المستوى</th>
                          <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الدكتور</th>
                          <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">النوع</th>
                          <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">إجراءات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {library.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                              لا يوجد محتوى معتمد
                            </td>
                          </tr>
                        ) : (
                          library.map((item) => (
                            <tr key={item.id} className="hover:bg-slate-50">
                              <td className="px-4 py-3 font-medium text-slate-800">{item.subject}</td>
                              <td className="px-4 py-3 text-slate-600">{item.college}</td>
                              <td className="px-4 py-3 text-slate-600">{item.level}</td>
                              <td className="px-4 py-3 text-slate-600">{item.doctor}</td>
                              <td className="px-4 py-3">
                                <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-700">
                                  {item.fileType}
                                </span>
                              </td>
                              <td className="px-4 py-3">
                                <button
                                  onClick={() => deleteLibraryItem(item.id)}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                  </svg>
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Certificates Tab */}
          {activeTab === 'certificates' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-800">طلبات الشهادات الإلكترونية</h2>
                <button
                  onClick={() => {
                    const headers = ['الاسم', 'الكلية', 'المستوى', 'التخصص', 'البريد الإلكتروني', 'الهاتف', 'نوع الشهادة', 'السبب', 'تاريخ الطلب', 'الحالة'];
                    const rows = certificates.map(c => [
                      c.fullName,
                      c.college,
                      c.level,
                      c.specialty,
                      c.email,
                      c.phone,
                      c.certificateType,
                      c.purpose,
                      new Date(c.requestDate).toLocaleDateString('ar-SA'),
                      c.status === 'pending' ? 'معلق' : c.status === 'sent' ? 'تم الإرسال' : 'مرفوض'
                    ]);
                    let csv = '\uFEFF';
                    csv += headers.join(',') + '\n';
                    rows.forEach(row => {
                      csv += row.map(cell => `"${cell}"`).join(',') + '\n';
                    });
                    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'طلبات_الشهادات.csv';
                    link.click();
                  }}
                  className="bg-emerald-500 text-white px-6 py-3 rounded-xl font-medium hover:bg-emerald-600 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span>تصدير Excel</span>
                </button>
              </div>

              {/* Pending Certificates */}
              {certificates.filter(c => c.status === 'pending').length > 0 && (
                <div className="mb-8">
                  <h3 className="text-xl font-bold text-amber-600 mb-4">
                    في انتظار الإرسال ({certificates.filter(c => c.status === 'pending').length})
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {certificates.filter(c => c.status === 'pending').map((cert) => (
                      <div key={cert.id} className="bg-white rounded-xl shadow-lg p-5 border border-amber-200">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-bold text-slate-800 text-lg">{cert.fullName}</h4>
                            <p className="text-sm text-slate-500">{cert.college} - المستوى {cert.level}</p>
                          </div>
                          <span className="px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-medium">
                            معلق
                          </span>
                        </div>
                        <div className="space-y-2 text-sm">
                          <p className="text-slate-600">
                            <span className="font-medium">البريد:</span> {cert.email}
                          </p>
                          <p className="text-slate-600">
                            <span className="font-medium">الهاتف:</span> {cert.phone || 'غير محدد'}
                          </p>
                          <p className="text-slate-600">
                            <span className="font-medium">نوع الشهادة:</span> {cert.certificateType}
                          </p>
                          <p className="text-slate-500 text-xs">
                            <span className="font-medium">السبب:</span> {cert.purpose}
                          </p>
                        </div>
                        <div className="mt-4 flex gap-2">
                          <button
                            onClick={() => {
                              if (confirm(`هل تريد إرسال الشهادة إلى ${cert.email}؟`)) {
                                storage.updateCertificate(cert.id, { status: 'sent', sentDate: new Date().toISOString() });
                                loadData();
                                alert('تم تحديث حالة الشهادة بنجاح');
                              }
                            }}
                            className="flex-1 bg-emerald-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-emerald-600"
                          >
                            تم الإرسال
                          </button>
                          <button
                            onClick={() => {
                              if (confirm('هل تريد رفض هذا الطلب؟')) {
                                storage.updateCertificate(cert.id, { status: 'rejected' });
                                loadData();
                              }
                            }}
                            className="flex-1 bg-red-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-600"
                          >
                            رفض
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sent Certificates */}
              {certificates.filter(c => c.status === 'sent').length > 0 && (
                <div className="mb-8">
                  <h3 className="text-xl font-bold text-emerald-600 mb-4">
                    تم الإرسال ({certificates.filter(c => c.status === 'sent').length})
                  </h3>
                  <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="bg-slate-100">
                          <tr>
                            <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الاسم</th>
                            <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">البريد الإلكتروني</th>
                            <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">نوع الشهادة</th>
                            <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">تاريخ الطلب</th>
                            <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">تاريخ الإرسال</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {certificates.filter(c => c.status === 'sent').map((cert) => (
                            <tr key={cert.id} className="hover:bg-slate-50">
                              <td className="px-4 py-3 font-medium text-slate-800">{cert.fullName}</td>
                              <td className="px-4 py-3 text-slate-600" dir="ltr">{cert.email}</td>
                              <td className="px-4 py-3">
                                <span className="px-2 py-1 rounded-full text-xs bg-emerald-100 text-emerald-700">
                                  {cert.certificateType}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-slate-600">{new Date(cert.requestDate).toLocaleDateString('ar-SA')}</td>
                              <td className="px-4 py-3 text-slate-600">{cert.sentDate ? new Date(cert.sentDate).toLocaleDateString('ar-SA') : '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {certificates.length === 0 && (
                <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold text-slate-700 mb-2">لا توجد طلبات شهادات</h3>
                  <p className="text-slate-500">سيظهر هنا أي طلبات شهادات جديدة</p>
                </div>
              )}
            </div>
          )}

          {/* Admins Tab */}
          {activeTab === 'admins' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-800">إدارة المشرفين</h2>
                <button
                  onClick={() => setShowAddAdmin(!showAddAdmin)}
                  className="bg-blue-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  <span>إضافة مشرف</span>
                </button>
              </div>

              {showAddAdmin && (
                <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
                  <h3 className="text-lg font-bold text-slate-800 mb-4">إضافة مشرف جديد</h3>
                  <form onSubmit={addNewAdmin} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">الاسم الرباعي</label>
                      <input
                        type="text"
                        required
                        value={newAdmin.fullName}
                        onChange={(e) => setNewAdmin({...newAdmin, fullName: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">البريد الإلكتروني</label>
                      <input
                        type="email"
                        required
                        value={newAdmin.email}
                        onChange={(e) => setNewAdmin({...newAdmin, email: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 outline-none"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">كلمة المرور</label>
                      <input
                        type="password"
                        required
                        value={newAdmin.password}
                        onChange={(e) => setNewAdmin({...newAdmin, password: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 outline-none"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">الكلية المسؤولة</label>
                      <select
                        required
                        value={newAdmin.college}
                        onChange={(e) => setNewAdmin({...newAdmin, college: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 outline-none"
                      >
                        <option value="">اختر الكلية</option>
                        {colleges.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>
                    <div className="md:col-span-2 flex gap-4">
                      <button type="submit" className="bg-emerald-500 text-white px-6 py-3 rounded-xl font-medium">
                        حفظ
                      </button>
                      <button type="button" onClick={() => setShowAddAdmin(false)} className="bg-slate-200 text-slate-700 px-6 py-3 rounded-xl font-medium">
                        إلغاء
                      </button>
                    </div>
                  </form>
                </div>
              )}

              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-slate-100">
                    <tr>
                      <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الاسم</th>
                      <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">البريد الإلكتروني</th>
                      <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الكلية</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr className="hover:bg-slate-50">
                      <td className="px-4 py-3 font-medium text-slate-800">{admin?.fullName}</td>
                      <td className="px-4 py-3 text-slate-600" dir="ltr">{admin?.email}</td>
                      <td className="px-4 py-3 text-slate-600">{admin?.college}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
