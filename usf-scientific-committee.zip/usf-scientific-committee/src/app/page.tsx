'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

export default function HomePage() {
  const [currentVerse, setCurrentVerse] = useState(0);
  const [isAnimating, setIsAnimating] = useState(true);

  const quranVerses = [
    {
      text: "اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ",
      explanation: "خَلَقَ الْإِنسَانَ مِنْ عَلَقٍ",
      source: "سورة العلق - الآية 1-2"
    },
    {
      text: "خَلَقَ الْإِنسَانَ مِنْ عَلَقٍ",
      explanation: "اقْرَأْ وَرَبُّكَ الْأَكْرَمُ",
      source: "سورة العلق - الآية 2-3"
    },
    {
      text: "الَّذِي عَلَّمَ بِالْقَلَمِ",
      explanation: "عَلَّمَ الْإِنسَانَ مَا لَمْ يَعْلَمْ",
      source: "سورة العلق - الآية 4-5"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(false);
      setTimeout(() => {
        setCurrentVerse((prev) => (prev + 1) % quranVerses.length);
        setIsAnimating(true);
      }, 500);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const joinSteps = [
    {
      number: 1,
      title: "العمل التطوعي الخيري",
      description: "أن يكون الانضمام عملاً تطوعياً خيرياً",
      icon: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
    },
    {
      number: 2,
      title: "الاستشعار بالأمانة",
      description: "استشعار الأمانة في تقديم المساعدة وكتابة الملخصات",
      icon: "M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
    },
    {
      number: 3,
      title: "التواجد في المحاضرات",
      description: "التواجد في المحاضرات الدراسية",
      icon: "M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
    },
    {
      number: 4,
      title: "الامتلاك للرغبة",
      description: "امتلاك الرغبة والنشاط والتعاون",
      icon: "M13 10V3L4 14h7v7l9-11h-7z"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-amber-50/30">
      <Navigation />
      
      {/* Hero Section - Quranic Verses with Slideshow */}
      <section className="pt-20 lg:pt-24 pb-20 lg:pb-32 bg-gradient-to-br from-indigo-950 via-purple-950 to-indigo-950 relative overflow-hidden min-h-screen flex items-center">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 right-0 w-full h-full">
            {[...Array(20)].map((_, i) => (
              <div
                key={i}
                className="absolute w-2 h-2 bg-amber-400 rounded-full animate-pulse"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 3}s`,
                  animationDuration: `${2 + Math.random() * 3}s`
                }}
              />
            ))}
          </div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          {/* Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-4 bg-white/10 backdrop-blur-md px-8 py-4 rounded-2xl mb-8 border border-white/20">
              <div className="w-14 h-14 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center shadow-2xl">
                <span className="text-indigo-950 font-black text-xl">USF</span>
              </div>
              <div className="text-right">
                <span className="text-white font-bold text-lg block">ملتقى الطالب الجامعي</span>
                <span className="text-amber-300 text-sm">جامعة 21 سبتمبر للعلوم الطبية والتطبيقية</span>
              </div>
            </div>
            <h1 className="text-4xl lg:text-6xl font-black text-white mb-4 drop-shadow-2xl">
              اللجنة العلمية المركزية
            </h1>
            <p className="text-amber-300 text-xl lg:text-2xl font-medium">
              نور العلم نورKNOWLEDGE
            </p>
          </div>

          {/* Quranic Verses Slideshow */}
          <div className="max-w-5xl mx-auto">
            <div className="relative bg-gradient-to-br from-white/15 to-white/5 backdrop-blur-xl rounded-3xl p-10 lg:p-16 border border-amber-400/30 shadow-2xl shadow-indigo-950/50">
              {/* Decorative corners */}
              <div className="absolute top-4 right-4 w-12 h-12 border-t-4 border-r-4 border-amber-400 rounded-tr-3xl"></div>
              <div className="absolute bottom-4 left-4 w-12 h-12 border-b-4 border-l-4 border-amber-400 rounded-bl-3xl"></div>
              
              {/* Verse Content */}
              <div className={`transition-all duration-700 ${isAnimating ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
                <div className="text-center">
                  {/* Bismillah */}
                  <p className="text-amber-300 text-xl mb-8 font-medium">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
                  
                  {/* Main Verse */}
                  <p 
                    className="text-4xl lg:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-400 leading-relaxed mb-6"
                    style={{ fontFamily: 'Amiri, serif' }}
                  >
                    ﴿{quranVerses[currentVerse].text}﴾
                  </p>
                  
                  {/* Second Part */}
                  <p 
                    className="text-2xl lg:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 to-teal-400 leading-relaxed mb-8"
                    style={{ fontFamily: 'Amiri, serif' }}
                  >
                    ﴿{quranVerses[currentVerse].explanation}﴾
                  </p>
                  
                  {/* Source */}
                  <div className="inline-flex items-center gap-3 bg-amber-500/20 px-6 py-3 rounded-full">
                    <svg className="w-5 h-5 text-amber-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                    <span className="text-amber-300 font-bold">{quranVerses[currentVerse].source}</span>
                  </div>
                </div>
              </div>

              {/* Navigation Dots */}
              <div className="flex justify-center gap-3 mt-8">
                {quranVerses.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setIsAnimating(false);
                      setTimeout(() => {
                        setCurrentVerse(index);
                        setIsAnimating(true);
                      }, 300);
                    }}
                    className={`w-4 h-4 rounded-full transition-all duration-300 ${
                      index === currentVerse 
                        ? 'bg-amber-400 w-10 shadow-lg shadow-amber-400/50' 
                        : 'bg-white/30 hover:bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Second Quranic Verses */}
          <div className="max-w-4xl mx-auto mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 text-center">
              <p 
                className="text-2xl lg:text-3xl font-bold text-amber-300 leading-relaxed mb-3"
                style={{ fontFamily: 'Amiri, serif' }}
              >
                ﴿قُلْ هَلْ يَسْتَوِي الَّذِينَ يَعْلَمُونَ وَالَّذِينَ لَا يَعْلَمُونَ﴾
              </p>
              <p className="text-emerald-300 text-sm font-medium">سورة الزمر - الآية 9</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 text-center">
              <p 
                className="text-2xl lg:text-3xl font-bold text-amber-300 leading-relaxed mb-3"
                style={{ fontFamily: 'Amiri, serif' }}
              >
                ﴿يَرْفَعِ اللَّهُ الَّذِينَ آمَنُوا مِنكُمْ وَالَّذِينَ أُوتُوا الْعِلْمَ دَرَجَاتٍ﴾
              </p>
              <p className="text-emerald-300 text-sm font-medium">سورة المجادلة - الآية 11</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section - Who We Are */}
      <section className="py-20 lg:py-28 bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-400"></div>
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="inline-block bg-indigo-100 text-indigo-800 px-4 py-2 rounded-full text-sm font-bold mb-4">تعرف علينا</span>
            <h2 className="text-4xl lg:text-5xl font-black text-indigo-950 mb-4">من نحن</h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-amber-500 to-yellow-500 mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {/* Vision */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-3xl p-10 text-center hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-indigo-100">
              <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-xl shadow-indigo-500/30">
                <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-black text-indigo-950 mb-6">رؤيتنا</h3>
              <div className="flex flex-wrap justify-center gap-3">
                {['وعي', 'تعلم', 'بناء', 'تطوير', 'تأهيل', 'تحفيز'].map((item) => (
                  <span key={item} className="bg-indigo-200 text-indigo-900 px-4 py-2 rounded-full text-sm font-bold">
                    {item}
                  </span>
                ))}
              </div>
            </div>

            {/* Mission */}
            <div className="bg-gradient-to-br from-amber-50 to-yellow-50 rounded-3xl p-10 text-center hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-amber-100">
              <div className="w-20 h-20 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-xl shadow-amber-500/30">
                <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-black text-amber-900 mb-6">رسالتنا</h3>
              <p className="text-amber-800 leading-relaxed text-lg font-medium">
                بالتكافل والوعي والبصيرة تنشأ الكوادر ذو الكفاءة والفاعلية في بناء الأمة
              </p>
            </div>

            {/* Goals */}
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-3xl p-10 text-center hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-emerald-100">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-xl shadow-emerald-500/30">
                <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                </svg>
              </div>
              <h3 className="text-2xl font-black text-emerald-900 mb-6">أهدافنا</h3>
              <ul className="text-emerald-800 space-y-4 text-right">
                <li className="flex items-center gap-3 justify-center font-medium">
                  <span className="w-3 h-3 bg-emerald-500 rounded-full"></span>
                  إحياء روح التعاون
                </li>
                <li className="flex items-center gap-3 justify-center font-medium">
                  <span className="w-3 h-3 bg-emerald-500 rounded-full"></span>
                  إيصال المعلومة بوضوح
                </li>
                <li className="flex items-center gap-3 justify-center font-medium">
                  <span className="w-3 h-3 bg-emerald-500 rounded-full"></span>
                  توسيع مدارك الطالب
                </li>
                <li className="flex items-center gap-3 justify-center font-medium">
                  <span className="w-3 h-3 bg-emerald-500 rounded-full"></span>
                  مواكبة التطور التكنولوجي
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Who We Are Banner */}
      <section className="py-20 lg:py-28 bg-gradient-to-br from-indigo-950 via-purple-950 to-indigo-950 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-amber-400 rounded-full blur-3xl"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-12 lg:p-16 border border-white/20">
              <div className="w-28 h-28 bg-gradient-to-br from-amber-400 to-yellow-500 rounded-2xl flex items-center justify-center mx-auto mb-10 shadow-2xl">
                <svg className="w-14 h-14 text-indigo-950" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <h3 className="text-3xl lg:text-5xl font-black text-white mb-6">
                كيان طلابي علمي تطوعي
              </h3>
              <p className="text-xl lg:text-2xl text-amber-300 leading-relaxed mb-8">
                نحن طلاب جامعة 21 سبتمبر للعلوم الطبية والتطبيقية، نعمل بكل جد وإخلاص لخدمة زملائنا الطلاب وتوفير المحتوى العلمي الذي يساعدهم في مسيرتهم الأكاديمية
              </p>
              <Link 
                href="/register"
                className="inline-flex items-center gap-4 bg-gradient-to-r from-amber-500 to-yellow-500 text-indigo-950 px-10 py-5 rounded-2xl font-black text-xl hover:shadow-2xl hover:shadow-amber-500/50 transition-all duration-300 hover:-translate-y-1"
              >
                <span>سجّل الآن</span>
                <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* How to Join */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-white to-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="inline-block bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-bold mb-4">انضم إلينا</span>
            <h2 className="text-4xl lg:text-5xl font-black text-indigo-950 mb-4">كيف تنضم إلينا؟</h2>
            <p className="text-slate-600 text-lg">اتبع الخطوات التالية للانضمام إلى اللجنة العلمية</p>
            <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 mx-auto rounded-full mt-4"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {joinSteps.map((step, index) => (
              <div 
                key={index}
                className="relative bg-white rounded-3xl p-8 hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 border border-slate-100 group"
              >
                <div className="absolute -top-5 right-8">
                  <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center text-white text-2xl font-black shadow-xl shadow-indigo-500/30 group-hover:scale-110 transition-transform">
                    {step.number}
                  </div>
                </div>
                <div className="pt-8 text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                    <svg className="w-8 h-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={step.icon} />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold text-indigo-950 mb-3">{step.title}</h3>
                  <p className="text-slate-600">{step.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-16">
            <Link 
              href="/register"
              className="inline-flex items-center gap-4 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 text-white px-12 py-6 rounded-2xl font-black text-xl hover:shadow-2xl hover:shadow-emerald-500/50 transition-all duration-300 hover:-translate-y-1"
            >
              <span>سجّل الآن في العضوية</span>
              <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 lg:py-28 bg-gradient-to-r from-indigo-950 via-purple-950 to-indigo-950 relative overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-400 rounded-full blur-3xl"></div>
          <div className="absolute top-0 left-0 w-96 h-96 bg-emerald-400 rounded-full blur-3xl"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            <div className="text-center">
              <div className="text-5xl lg:text-7xl font-black text-white mb-3">9</div>
              <p className="text-amber-300 font-bold text-lg">كليات</p>
            </div>
            <div className="text-center">
              <div className="text-5xl lg:text-7xl font-black text-white mb-3">5</div>
              <p className="text-amber-300 font-bold text-lg">مستويات</p>
            </div>
            <div className="text-center">
              <div className="text-5xl lg:text-7xl font-black text-white mb-3">100+</div>
              <p className="text-amber-300 font-bold text-lg">قناة علمية</p>
            </div>
            <div className="text-center">
              <div className="text-5xl lg:text-7xl font-black text-white mb-3">1000+</div>
              <p className="text-amber-300 font-bold text-lg">طالب مستفيد</p>
            </div>
          </div>
        </div>
      </section>

      {/* Certificate CTA */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-amber-50 to-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-amber-500 via-yellow-500 to-amber-600 rounded-3xl p-12 lg:p-16 text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2"></div>
              <div className="relative z-10">
                <div className="w-24 h-24 bg-white rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-2xl">
                  <svg className="w-14 h-14 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                  </svg>
                </div>
                <h3 className="text-3xl lg:text-4xl font-black text-indigo-950 mb-4">
                  احصل على شهادتك الإلكترونية
                </h3>
                <p className="text-indigo-900 text-xl mb-8 font-medium">
                  سجّل بياناتك للحصول على شهادة التقدير المقدمة من ملتقى الطالب الجامعي
                </p>
                <Link 
                  href="/certificate"
                  className="inline-flex items-center gap-3 bg-indigo-950 text-white px-10 py-5 rounded-2xl font-bold text-lg hover:bg-indigo-900 hover:shadow-2xl transition-all duration-300"
                >
                  <span>تسجيل للحصول على الشهادة</span>
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
