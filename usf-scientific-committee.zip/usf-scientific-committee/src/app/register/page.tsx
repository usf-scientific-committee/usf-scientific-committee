'use client';

import { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { colleges, levels } from '@/data/channels';
import { storage, Member } from '@/data/types';

export default function RegisterPage() {
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successName, setSuccessName] = useState('');
  const [isAlreadyRegistered, setIsAlreadyRegistered] = useState(false);
  
  const [formData, setFormData] = useState({
    fullName: '',
    college: '',
    level: '',
    gender: '' as 'ذكر' | 'أنثى' | '',
    phone: '',
    role: '',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // التحقق من التسجيل المسبق
    if (storage.memberExists(formData.fullName)) {
      setIsAlreadyRegistered(true);
      setShowError(true);
      setErrorMessage('عزيزي الطالب/ة لقد قمت بالتسجيل في اللجنة العلمية سابقاً لا يمكنك التسجيل مرة أخرى شكراً لك');
      return;
    }

    const newMember: Member = {
      id: Date.now().toString(),
      fullName: formData.fullName,
      college: formData.college,
      level: formData.level,
      gender: formData.gender as 'ذكر' | 'أنثى',
      phone: formData.phone || undefined,
      role: formData.role || undefined,
      notes: formData.notes || undefined,
      registrationDate: new Date().toISOString()
    };

    storage.addMember(newMember);
    setSuccessName(formData.fullName);
    setShowSuccess(true);
    
    // إعادة تعيين النموذج
    setFormData({
      fullName: '',
      college: '',
      level: '',
      gender: '',
      phone: '',
      role: '',
      notes: ''
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation />
      
      {/* Success Message */}
      {showSuccess && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-6 rounded-2xl shadow-2xl text-center max-w-md animate-bounce">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="text-xl font-bold mb-2">أهلاً بك {successName}</h3>
          <p className="text-white/90">في اللجنة العلمية نتمنى أن تكون من الطلاب الذين يقدمون العون والمساعدة لطلاب الجامعة</p>
          <button
            onClick={() => setShowSuccess(false)}
            className="mt-4 bg-white/20 px-6 py-2 rounded-lg font-medium hover:bg-white/30 transition-colors"
          >
            حسناً
          </button>
        </div>
      )}

      {/* Error Message */}
      {showError && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-red-500 text-white px-8 py-6 rounded-2xl shadow-2xl text-center max-w-md">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <p className="text-lg font-medium">{errorMessage}</p>
          <button
            onClick={() => setShowError(false)}
            className="mt-4 bg-white/20 px-6 py-2 rounded-lg font-medium hover:bg-white/30 transition-colors"
          >
            حسناً
          </button>
        </div>
      )}

      {/* Hero Section */}
      <section className="pt-24 lg:pt-32 pb-12 bg-gradient-to-br from-blue-900 via-blue-800 to-emerald-900">
        <div className="container mx-auto px-4 text-center">
          <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <svg className="w-12 h-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
            </svg>
          </div>
          <h1 className="text-3xl lg:text-5xl font-bold text-white mb-4">تسجيل العضوية</h1>
          <p className="text-blue-200 text-lg">انضم إلى عائلة اللجنة العلمية المركزية</p>
        </div>
      </section>

      {/* Registration Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
              {/* Header */}
              <div className="bg-gradient-to-r from-blue-600 to-emerald-500 px-8 py-6">
                <h2 className="text-2xl font-bold text-white">نموذج التسجيل</h2>
                <p className="text-white/80">الرجاء ملء جميع البيانات المطلوبة</p>
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="p-8 space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    الاسم الرباعي *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all text-lg"
                    placeholder="أدخل اسمك الرباعي"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      الكلية *
                    </label>
                    <select
                      required
                      value={formData.college}
                      onChange={(e) => setFormData({...formData, college: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    >
                      <option value="">اختر الكلية</option>
                      {colleges.map(col => (
                        <option key={col} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      المستوى *
                    </label>
                    <select
                      required
                      value={formData.level}
                      onChange={(e) => setFormData({...formData, level: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    >
                      <option value="">اختر المستوى</option>
                      {levels.map(level => (
                        <option key={level} value={level}>المستوى {level}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      الجنس *
                    </label>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="gender"
                          value="ذكر"
                          checked={formData.gender === 'ذكر'}
                          onChange={(e) => setFormData({...formData, gender: e.target.value as 'ذكر' | 'أنثى'})}
                          className="w-5 h-5 text-emerald-500 focus:ring-emerald-500"
                        />
                        <span className="text-slate-700">ذكر</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="gender"
                          value="أنثى"
                          checked={formData.gender === 'أنثى'}
                          onChange={(e) => setFormData({...formData, gender: e.target.value as 'ذكر' | 'أنثى'})}
                          className="w-5 h-5 text-emerald-500 focus:ring-emerald-500"
                        />
                        <span className="text-slate-700">أنثى</span>
                      </label>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      رقم الهاتف
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      placeholder="رقم الهاتف (اختياري)"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    العمل الحالي في اللجنة العلمية
                  </label>
                  <input
                    type="text"
                    value={formData.role}
                    onChange={(e) => setFormData({...formData, role: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    placeholder="مثال: مسؤول قسم التشريح"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    ملاحظات لتطوير اللجنة العلمية
                  </label>
                  <textarea
                    rows={4}
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all resize-none"
                    placeholder="اكتب أي ملاحظات أو اقتراحات..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:shadow-xl transition-all flex items-center justify-center gap-3"
                >
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>تسجيل</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
