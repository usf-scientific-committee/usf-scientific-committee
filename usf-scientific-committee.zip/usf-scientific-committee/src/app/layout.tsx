import type { Metadata } from "next";
import { Tajawal, Amiri } from "next/font/google";
import "./globals.css";

const tajawal = Tajawal({
  weight: ['400', '500', '700', '800'],
  subsets: ["arabic"],
  variable: "--font-tajawal",
});

const amiri = Amiri({
  weight: ['400', '700'],
  subsets: ["arabic"],
  variable: "--font-amiri",
});

export const metadata: Metadata = {
  title: "اللجنة العلمية المركزية | جامعة 21 سبتمبر",
  description: "ملتقى الطالب الجامعي - جامعة 21 سبتمبر للعلوم الطبية والتطبيقية",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" className={`${tajawal.variable} ${amiri.variable}`}>
      <body className="min-h-full flex flex-col font-sans">
        {children}
      </body>
    </html>
  );
}
