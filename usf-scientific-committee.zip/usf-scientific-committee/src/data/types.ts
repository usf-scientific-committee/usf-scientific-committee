// أنواع البيانات

export interface Member {
  id: string;
  fullName: string;
  college: string;
  level: string;
  gender: 'ذكر' | 'أنثى';
  phone?: string;
  role?: string;
  notes?: string;
  registrationDate: string;
}

export interface LibraryItem {
  id: string;
  college: string;
  level: string;
  term?: string;
  subject: string;
  doctor: string;
  fileType: string;
  specialty: string;
  uploaderName?: string;
  fileName: string;
  fileUrl: string;
  status: 'pending' | 'approved' | 'rejected';
  uploadDate: string;
}

export interface ContactMessage {
  id: string;
  fullName: string;
  college: string;
  level: string;
  specialty: string;
  phone: string;
  message: string;
  date: string;
}

export interface Admin {
  id: string;
  fullName: string;
  email: string;
  password: string;
  college: string;
  createdAt: string;
}

export interface CertificateRequest {
  id: string;
  fullName: string;
  college: string;
  level: string;
  specialty: string;
  email: string;
  phone: string;
  certificateType: string;
  purpose: string;
  requestDate: string;
  status: 'pending' | 'sent' | 'rejected';
  sentDate?: string;
  adminNotes?: string;
}

// بيانات المشرفين الافتراضية
export const defaultAdmins: Admin[] = [
  {
    id: 'admin-1',
    fullName: 'مدير النظام',
    email: 'Wjhb29ytsbvk.wo@gmail.com',
    password: 'MOHAMMED774665526',
    college: 'الكل',
    createdAt: new Date().toISOString()
  }
];

// دوال المساعدة للتخزين المحلي
const STORAGE_KEYS = {
  MEMBERS: 'usf_scientific_committee_members',
  LIBRARY: 'usf_scientific_committee_library',
  PENDING: 'usf_scientific_committee_pending',
  CONTACTS: 'usf_scientific_committee_contacts',
  ADMINS: 'usf_scientific_committee_admins',
  CERTIFICATES: 'usf_scientific_committee_certificates'
};

export const storage = {
  // الأعضاء
  getMembers: (): Member[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.MEMBERS);
    return data ? JSON.parse(data) : [];
  },
  
  saveMembers: (members: Member[]) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  },
  
  addMember: (member: Member) => {
    const members = storage.getMembers();
    members.push(member);
    storage.saveMembers(members);
  },
  
  deleteMember: (id: string) => {
    const members = storage.getMembers().filter(m => m.id !== id);
    storage.saveMembers(members);
  },
  
  memberExists: (fullName: string): boolean => {
    const members = storage.getMembers();
    return members.some((m: Member) => m.fullName === fullName);
  },
  
  // المكتبة
  getLibrary: (): LibraryItem[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.LIBRARY);
    return data ? JSON.parse(data) : [];
  },
  
  saveLibrary: (items: LibraryItem[]) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.LIBRARY, JSON.stringify(items));
  },
  
  addToLibrary: (item: LibraryItem) => {
    const library = storage.getLibrary();
    library.push(item);
    storage.saveLibrary(library);
  },
  
  // المحتوى المعلق
  getPending: (): LibraryItem[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.PENDING);
    return data ? JSON.parse(data) : [];
  },
  
  savePending: (items: LibraryItem[]) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.PENDING, JSON.stringify(items));
  },
  
  addPending: (item: LibraryItem) => {
    const pending = storage.getPending();
    pending.push(item);
    storage.savePending(pending);
  },
  
  approveItem: (id: string) => {
    const pending = storage.getPending();
    const item = pending.find((i: LibraryItem) => i.id === id);
    if (item) {
      item.status = 'approved';
      storage.addToLibrary(item);
      storage.savePending(pending.filter(i => i.id !== id));
    }
  },
  
  rejectItem: (id: string) => {
    const pending = storage.getPending();
    storage.savePending(pending.filter(i => i.id !== id));
  },
  
  // الرسائل
  getContacts: (): ContactMessage[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.CONTACTS);
    return data ? JSON.parse(data) : [];
  },
  
  saveContacts: (messages: ContactMessage[]) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify(messages));
  },
  
  addContact: (message: ContactMessage) => {
    const contacts = storage.getContacts();
    contacts.push(message);
    storage.saveContacts(contacts);
  },
  
  // المشرفين
  getAdmins: (): Admin[] => {
    if (typeof window === 'undefined') return defaultAdmins;
    const data = localStorage.getItem(STORAGE_KEYS.ADMINS);
    const admins = data ? JSON.parse(data) : defaultAdmins;
    if (!admins.find((a: Admin) => a.email === 'Wjhb29ytsbvk.wo@gmail.com')) {
      admins.push(defaultAdmins[0]);
    }
    return admins;
  },
  
  saveAdmins: (admins: Admin[]) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.ADMINS, JSON.stringify(admins));
  },
  
  addAdmin: (admin: Admin) => {
    const admins = storage.getAdmins();
    admins.push(admin);
    storage.saveAdmins(admins);
  },
  
  loginAdmin: (email: string, password: string): Admin | null => {
    const admins = storage.getAdmins();
    return admins.find((a: Admin) => a.email === email && a.password === password) || null;
  },

  // الشهادات
  getCertificates: (): CertificateRequest[] => {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEYS.CERTIFICATES);
    return data ? JSON.parse(data) : [];
  },

  saveCertificates: (certificates: CertificateRequest[]) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.CERTIFICATES, JSON.stringify(certificates));
  },

  addCertificate: (certificate: CertificateRequest) => {
    const certificates = storage.getCertificates();
    certificates.push(certificate);
    storage.saveCertificates(certificates);
  },

  updateCertificate: (id: string, updates: Partial<CertificateRequest>) => {
    const certificates = storage.getCertificates();
    const index = certificates.findIndex((c: CertificateRequest) => c.id === id);
    if (index !== -1) {
      certificates[index] = { ...certificates[index], ...updates };
      storage.saveCertificates(certificates);
    }
  },

  deleteCertificate: (id: string) => {
    const certificates = storage.getCertificates().filter(c => c.id !== id);
    storage.saveCertificates(certificates);
  }
};
