// بيانات روابط القنوات من ملف Excel
export interface Channel {
  link: string;
  channelName: string;
  officialName: string;
  university: string;
  college: string;
  specialty: string;
  level: string;
}

export const channels: Channel[] = [
  {
    link: "https://t.me/USF_nursing_6",
    channelName: "اللجنة العلمية الدفعة السادسة",
    officialName: "اللجنة العلمية الدفعة السادسة تمريض",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب المخبري",
    specialty: "تمريض",
    level: "رابع"
  },
  {
    link: "https://t.me/Lab821spt",
    channelName: "كلية الطب المخبري USF3",
    officialName: "الدفعة الثامنة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب المخبري",
    specialty: "طب مخبري",
    level: "ثالث"
  },
  {
    link: "https://t.me/laboratorial_7",
    channelName: "كلية الطب المخبري USF4",
    officialName: "اللجنة العلمية للدفعة السابعة (كلية الطب المخبري)",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب المخبري",
    specialty: "طب مخبري",
    level: "رابع"
  },
  {
    link: "https://t.me/batch10_USF_21",
    channelName: "اللجنة العلمية-الدفعة العاشرة |USF|",
    officialName: "اللجنة العلمية-الدفعة العاشرة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/Sport7thBatch",
    channelName: "اللجنة الرياضية للدفعة السابعة |USF|",
    officialName: "اللجنة الرياضية للدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/Seventh_Scientific_Channel_USF",
    channelName: "اللجنة العلمية_الدفعة السابعة |USF|",
    officialName: "اللجنة العلمية_الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/Anatomy_th7",
    channelName: "قسم Anatomy الدفعة السابعة |USF|",
    officialName: "قسم Anatomy الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/Biochemistry_th7",
    channelName: "قسم Biochemistry الدفعة السابعة |USF|",
    officialName: "قسم Biochemistry الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/Histology_th7",
    channelName: "قسم Histology الدفعة السابعة |USF|",
    officialName: "قسم Histology الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/medicine_7th_batch",
    channelName: "قسم Medicine الدفعة السابعة |USF|",
    officialName: "قسم Medicine الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/medicine_8th",
    channelName: "قسم Medicine دفعة |USF|",
    officialName: "قسم Medicine دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/Microbiology_th7",
    channelName: "قسم Microbiology الدفعة السابعة |USF|",
    officialName: "قسم Microbiology الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/pbl7th",
    channelName: "قسم PBL الدفعة السابعة |USF|",
    officialName: "قسم PBL الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/pbl_8th",
    channelName: "قسم PBL دفعة |USF|",
    officialName: "قسم PBL دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/Parasitology_th7",
    channelName: "قسم Parasitology الدفعة السابعة |USF|",
    officialName: "قسم Parasitology الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/parastologcom",
    channelName: "قسم Parasitology الدفعة الثامنة",
    officialName: "قسم Parasitology الدفعة الثامنة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/Pathology_th7",
    channelName: "قسم Pathology الدفعة السابعة |USF|",
    officialName: "قسم Pathology الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/pathology_8th",
    channelName: "قسم Pathology دفعة |USF|",
    officialName: "قسم Pathology دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/pediatrics_7th_batch",
    channelName: "قسم Pediatrics الدفعة السابعة |USF|",
    officialName: "قسم Pediatrics الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/Pharmacology_th7",
    channelName: "قسم Pharmacology الدفعة السابعة |USF|",
    officialName: "قسم Pharmacology الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/pharmacology_8th",
    channelName: "قسم Pharmacology دفعة |USF|",
    officialName: "قسم Pharmacology دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/Physiology_th7",
    channelName: "قسم Physiology الدفعة السابعة |USF|",
    officialName: "قسم Physiology الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/physiology_th8",
    channelName: "قسم Physiology دفعة |USF|",
    officialName: "قسم Physiology دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/surgery_8th",
    channelName: "قسم Surgery دفعة |USF|",
    officialName: "قسم Surgery دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/anatomy_th8",
    channelName: "قسم ال Anatomy دفعة |USF|",
    officialName: "قسم ال Anatomy دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/histology_8th",
    channelName: "قسم ال Histology دفعة |USF|",
    officialName: "قسم ال Histology دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/paediatrics_8",
    channelName: "قسم الاطفال || Paediatrics دفعة |USF|",
    officialName: "قسم الاطفال || Paediatrics دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/theseventhbatchreviewplace",
    channelName: "قسم التقوية والشمولي الدفعة السابعة |USF|",
    officialName: "قسم التقوية والشمولي الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/lab_8th",
    channelName: "قسم العملي || LAB دفعة |USF|",
    officialName: "قسم العملي || LAB دفعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/LAB_section_7th_batch",
    channelName: "قسم الـعملي || LAB الدفعة السابعة |USF|",
    officialName: "قسم الـعملي || LAB الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/mcq_8th",
    channelName: "قناة MCQ |دفعة|",
    officialName: "قناة MCQ |دفعة|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثامن"
  },
  {
    link: "https://t.me/Surgery7thbatch",
    channelName: "قناة Surgery الدفعة السابعة |USF|",
    officialName: "قناة Surgery الدفعة السابعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/TheBestPlaceforYoud",
    channelName: "مكتبة اللجنة العلمية للدفعة السابعة|USF|",
    officialName: "مكتبة اللجنة العلمية للدفعة السابعة|USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثالث"
  },
  {
    link: "https://t.me/pathology_th9",
    channelName: "قسم (Pathology) الدفعة التاسعة |USF|",
    officialName: "قسم (Pathology) الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/anatomy_th9",
    channelName: "قسم (Anatomy) الدفعة التاسعة",
    officialName: "قسم (Anatomy) الدفعة التاسعة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/mad34278",
    channelName: "قسم (Biostatistics & Community Medicine) الدفعة التاسعة",
    officialName: "قسم (Biostatistics & Community Medicine) الدفعة التاسعة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/Microbiology_th9",
    channelName: "قسم (Microbiology) الدفعة التاسعة |USF|",
    officialName: "قسم (Microbiology) الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/biochemistry_th9",
    channelName: "قسم Biochemistry الدفعة التاسعة |USF|",
    officialName: "قسم Biochemistry الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/histology_th9",
    channelName: "قسم Histology الدفعة التاسعة |USF|",
    officialName: "قسم Histology الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/requirement_th9",
    channelName: "قسم Medical Requirement الدفعة التاسعة |USF|",
    officialName: "قسم Medical Requirement الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/Parasitology_th9",
    channelName: "قسم Parasitology الدفعة التاسعة |USF|",
    officialName: "قسم Parasitology الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/pharmacology_th9",
    channelName: "قسم pharmacology الدفعة التاسعة |USF|",
    officialName: "قسم pharmacology الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/physiology_th9",
    channelName: "قسم physiology الدفعة التاسعة |USF|",
    officialName: "قسم physiology الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/PBL_9USF",
    channelName: "قسم ال PBL الدفعة التاسعة |USF|",
    officialName: "قسم ال PBL الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/medicine_9USF",
    channelName: "قسم الباطنة الدفعة التاسعة |USF|",
    officialName: "قسم الباطنة الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/surgery_9USF",
    channelName: "قسم الجراحة الدفعة التاسعة |USF|",
    officialName: "قسم الجراحة الدفعة التاسعة |USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "ثاني"
  },
  {
    link: "https://t.me/Pediatrics_batch_6",
    channelName: "(Pediatrics Section) قسم الأطفال_الدفعة السادسة",
    officialName: "(Pediatrics Section) قسم الأطفال_الدفعة السادسة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "رابع"
  },
  {
    link: "https://t.me/gyneandobstetrics",
    channelName: "قسم ال Gynecology & obstetrics للدفعة السادسة",
    officialName: "قسم ال Gynecology & obstetrics للدفعة السادسة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "رابع"
  },
  {
    link: "https://t.me/practicalgyn",
    channelName: "قسم الـ(Practical Obs&Gyne) _الدفعة السادسة",
    officialName: "قسم الـ(Practical Obs&Gyne) _الدفعة السادسة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "رابع"
  },
  {
    link: "https://t.me/practicalpedi",
    channelName: "قسم الـ(Practical Pediatrics) _الدفعة السادسة",
    officialName: "قسم الـ(Practical Pediatrics) _الدفعة السادسة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "رابع"
  },
  {
    link: "https://t.me/practicalsurger",
    channelName: "قسم الـ(Practical Surgery) _الدفعة السادسة",
    officialName: "قسم الـ(Practical Surgery) _الدفعة السادسة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "رابع"
  },
  {
    link: "https://t.me/Medicine_6",
    channelName: "قسم الـ(Internal Medicine) _الدفعة السادسة",
    officialName: "قسم الـ(Internal Medicine) _الدفعة السادسة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "رابع"
  },
  {
    link: "https://t.me/parcticalmedi",
    channelName: "قسم الـ(Practical Medicine) _الدفعة السادسة",
    officialName: "قسم الـ(Practical Medicine) _الدفعة السادسة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "رابع"
  },
  {
    link: "https://t.me/Surgery_batch6",
    channelName: "قسم الـ(Surgery) _الدفعة السادسة",
    officialName: "قسم الـ(Surgery) _الدفعة السادسة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "رابع"
  },
  {
    link: "https://t.me/BS1_medical_science",
    channelName: "اللجنة العلمية الدفعة الأولى كلية العلوم الطبية",
    officialName: "اللجنة العلمية للدفعة الأولى كلية العلوم الطبية",
    university: "جامعة 21 سبتمبر",
    college: "كلية العلوم الطبية التطبيقية",
    specialty: "مشترك",
    level: "أول"
  },
  {
    link: "https://t.me/USF_21UMAS_Nursing_1st",
    channelName: "اللجنة العلمية الدفعة الثامنة التمريض العالي",
    officialName: "اللجنة العلمية الدفعة الثامنة التمريض العالي",
    university: "جامعة 21 سبتمبر",
    college: "كلية التمريض العالي",
    specialty: "تمريض",
    level: "ثالث"
  },
  {
    link: "https://t.me/TheNursing2september10",
    channelName: "لجنة دفعة عاشرة",
    officialName: "اللجنة العلمية الدفعة العاشرة كلية التمريض العالي",
    university: "جامعة 21 سبتمبر",
    college: "كلية التمريض العالي",
    specialty: "تمريض",
    level: "أول"
  },
  {
    link: "https://t.me/USF_nurse",
    channelName: "لجنة دفعة تاسعة",
    officialName: "اللجنة العلمية الدفعة التاسعة كلية التمريض",
    university: "جامعة 21 سبتمبر",
    college: "كلية التمريض العالي",
    specialty: "تمريض",
    level: "خامس"
  },
  {
    link: "https://t.me/the_7th_scientific_committee",
    channelName: "لجنة دفعة سابعة",
    officialName: "اللجنة العلمية للدفعة صيدلة سريرية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "أول"
  },
  {
    link: "https://t.me/Ph_USF_10",
    channelName: "لجنة دفعة عاشرة",
    officialName: "اللجنة العلمية دفعة صيدلة سريرية USF",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "أول"
  },
  {
    link: "https://t.me/pharmaknowledge",
    channelName: "Pharma Knowledge | اللجنة العلمية – دفعة 8",
    officialName: "Pharma Knowledge | اللجنة العلمية – دفعة 8",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "ثالث"
  },
  {
    link: "https://t.me/pharmacutices7",
    channelName: "Pharmacutices| صيدلانيات",
    officialName: "Pharmacutices| صيدلانيات",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "ثالث"
  },
  {
    link: "https://t.me/the_8th_scientific_committee",
    channelName: "لجنة دفعة ثامنة",
    officialName: "اللجنة العلمية الدفعة كلية الصيدلة السريرية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "ثالث"
  },
  {
    link: "https://t.me/Ph_USF_9",
    channelName: "لجنة دفعة تاسعة",
    officialName: "اللجنة العلمية الدفعة كلية الصيدلة السريرية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "ثاني"
  },
  {
    link: "https://t.me/doctor21sep",
    channelName: "لجنة الدفعة السادسة",
    officialName: "اللجنة العلمية الدفعة السادسة صيدلة سريرية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "خامس"
  },
  {
    link: "https://t.me/pharmalogy7",
    channelName: "Pharmacology| فارما علم الأدوية",
    officialName: "Pharmacology| فارما علم الأدوية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "رابع"
  },
  {
    link: "https://t.me/therapeutic7",
    channelName: "علاجيات وحالات سريرية | Therapeutic & Cases",
    officialName: "علاجيات وحالات سريرية | Therapeutic & Cases",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "رابع"
  },
  {
    link: "https://t.me/USF_Scientific_Committe",
    channelName: "اللجنة المركزية",
    officialName: "اللجنة العلمية كلية الصيدلة USF",
    university: "جامعة 21 سبتمبر",
    college: "كلية الصيدلة السريرية",
    specialty: "صيدلة",
    level: "شامل"
  },
  {
    link: "https://t.me/USF_lab_8",
    channelName: "اللجنة العلمية الدفعة الثامنة",
    officialName: "اللجنة العلمية الدفعة الثامنة كلية الطب المخبري",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب المخبري",
    specialty: "مختبرات",
    level: "ثالث"
  },
  {
    link: "https://t.me/USF_lab_10",
    channelName: "كلية الطب المخبري USF1",
    officialName: "اللجنة العلمية الدفعة العاشرة الطب المخبري USF",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب المخبري",
    specialty: "طب مخبري",
    level: "أول"
  },
  {
    link: "https://t.me/USF_lab_9",
    channelName: "كلية الطب المخبري USF2",
    officialName: "اللجنة العلمية الدفعة التاسعة الطب المخبري",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب المخبري",
    specialty: "طب مخبري",
    level: "ثاني"
  },
  {
    link: "https://t.me/Clinical_pharmacy9ninth",
    channelName: "اللجنة العلمية الدفعة كلية الصيدلة السريرية",
    officialName: "اللجنة العلمية الدفعة كلية الصيدلة السريرية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب المخبري",
    specialty: "مختبرات",
    level: "شامل"
  },
  {
    link: "https://t.me/mangnerUSF8",
    channelName: "اللجنة العلمية الدفعة كلية الإدارة الطبية",
    officialName: "اللجنة العلمية الدفعة كلية الإدارة الطبية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "إدارة طبية",
    level: "ثالث"
  },
  {
    link: "https://t.me/anatomt_Batch10",
    channelName: "Anatomy |USF| - Batch10",
    officialName: "Anatomy |USF| - Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/biochemistry_Batch10",
    channelName: "Biochemistry |USF|-batch 10",
    officialName: "Biochemistry |USF|-batch 10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/commustatic_21uni_batch10",
    channelName: "Biostatistics & Community Medicine |USF| -Batch10",
    officialName: "Biostatistics & Community Medicine |USF| -Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/histology_Batch10",
    channelName: "Histology |USF|-Batch10",
    officialName: "Histology |USF|-Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/labs_21uni_batch10",
    channelName: "Labs |USF| -Batch10",
    officialName: "Labs |USF| -Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/medical_Req",
    channelName: "Medical Requirement |USF|-Batch10",
    officialName: "Medical Requirement |USF|-Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/nutrmeta_uni21batch10",
    channelName: "Metabolism&Nutrition |USF| -Batch10",
    officialName: "Metabolism&Nutrition |USF| -Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/micro_uni21batch10",
    channelName: "Microbiology |USF| -Batch10",
    officialName: "Microbiology |USF| -Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/para_uni21batch10",
    channelName: "Parasitology |USF| -Batch10",
    officialName: "Parasitology |USF| -Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/Patho_uni21batch10",
    channelName: "Pathology |USF|- Batch10",
    officialName: "Pathology |USF|- Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/pharma_uni21batch10",
    channelName: "Pharmacology |USF| -Batch10",
    officialName: "Pharmacology |USF| -Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/physiology_Batch10",
    channelName: "Physiology |USF| - Batch10",
    officialName: "Physiology |USF| - Batch10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/Tests_questions_10th",
    channelName: "قسم | كوزات ونماذج | الدفعة 10",
    officialName: "قسم | كوزات ونماذج | الدفعة 10",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "أول"
  },
  {
    link: "https://t.me/sixtth_scientific_channel",
    channelName: "اللجنة العلمية_للدفعة السادسة|USF|",
    officialName: "اللجنة العلمية_للدفعة السادسة|USF|",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "طب بشري",
    level: "خامس"
  },
  {
    link: "https://t.me/USF_21University_10",
    channelName: "نماذج قبول وملخصات جامعة 21 سبتمبر USF",
    officialName: "نماذج قبول وملخصات جامعة 21 سبتمبر USF",
    university: "جامعة 21 سبتمبر",
    college: "كلية الطب والعلوم الصحية",
    specialty: "غير مصنف",
    level: "أول"
  },
  {
    link: "https://t.me/the_3nd_scientific_committee",
    channelName: "اللجنة العلمية-دفعة ثالثة كلية العلوم الطبية التطبيقية USF",
    officialName: "اللجنة العلمية-دفعة ثالثة كلية العلوم الطبية التطبيقية USF",
    university: "جامعة 21 سبتمبر",
    college: "كلية العلوم الطبية",
    specialty: "غير مصنف",
    level: "ثالث"
  },
  {
    link: "https://t.me/the_2nd_scientific_committee",
    channelName: "اللجنة العلمية الدفعة الثانية كلية العلوم الطبية",
    officialName: "اللجنة العلمية_الدفعة الثانية_كلية العلوم الطبية التطبيقية",
    university: "جامعة 21 سبتمبر",
    college: "كلية العلوم الطبية التطبيقية",
    specialty: "مشترك",
    level: "ثاني"
  },
  {
    link: "https://t.me/Second_batch_scientific_commitee",
    channelName: "اللجنة العلمية طب وجراحة الفم والأسنان الدفعة الثانية (مستوى أول) USF",
    officialName: "اللجنة العلمية طب وجراحة الفم والأسنان الدفعة الثانية (مستوى أول) USF",
    university: "جامعة 21 سبتمبر",
    college: "كلية طب الأسنان",
    specialty: "طب الأسنان",
    level: "أول"
  },
  {
    link: "https://t.me/first_batch_scientific_commitee",
    channelName: "اللجنة العلمية |USF| طب الأسنان",
    officialName: "اللجنة العلمية |USF| طب الأسنان",
    university: "جامعة 21 سبتمبر",
    college: "كلية طب الأسنان",
    specialty: "طب الأسنان",
    level: "ثاني"
  },
  {
    link: "https://t.me/IT_TEK_C7",
    channelName: "قناة اللجنة العلمية الدفعة الرابعة كلية الهندسة والحاسوب",
    officialName: "اللجنة العلمية الدفعة الرابعة كلية الهندسة والحاسوب",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "IT",
    level: "أول"
  },
  {
    link: "https://t.me/IT2_Academic_Committee",
    channelName: "اللجنة العلمية الدفعة الثانية IT",
    officialName: "اللجنة العلمية الدفعة الثانية IT",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "IT",
    level: "ثالث"
  },
  {
    link: "https://t.me/umas21m",
    channelName: "اللجنة العلمية-Itالدفعة الثالثة",
    officialName: "اللجنة العلمية-Itالدفعة الثالثة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "IT",
    level: "ثاني"
  },
  {
    link: "https://t.me/laithalgalobNew",
    channelName: "ملتقى طلاب تكنولوجيا المعلومات الطبية(الدفعة الأولى)",
    officialName: "ملتقى طلاب تكنولوجيا المعلومات الطبية(الدفعة الأولى)",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "IT",
    level: "رابع"
  },
  {
    link: "https://t.me/Cyber21Sep",
    channelName: "اللجنة العلمية الدفعة الرابعة تخصص آمن سيبراني",
    officialName: "اللجنة العلمية الدفعة الرابعة تخصص آمن سيبراني",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "آمن سيبراني",
    level: "أول"
  },
  {
    link: "https://t.me/USF21technology4",
    channelName: "قناة اللجنة العلمية الدفعة الرابعة كلية الهندسة والحاسوب",
    officialName: "اللجنة العلمية الدفعة الرابعة كلية الهندسة والحاسوب",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "كل التخصصات",
    level: "أول"
  },
  {
    link: "https://t.me/Bio_engineering2",
    channelName: "اللجنة العلمية للدفعة هندسة الطبية حيوية",
    officialName: "اللجنة العلمية للدفعة هندسة الطبية حيوية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "هندسة طبية",
    level: "ثالث"
  },
  {
    link: "https://t.me/Medical_Technology_3_commitee",
    channelName: "اللجنة العلمية الدفعة (هندسة -معلومات)طبية",
    officialName: "اللجنة العلمية الدفعة (هندسة -معلومات)طبية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "هندسة طبية",
    level: "ثاني"
  },
  {
    link: "https://t.me/Medical_devices_Technology",
    channelName: "قناة اللجنة العلمية-جامعة 21 سبتمبر-كلية الهندسة-قسم الأجهزة الطبية-المستوى الرابع",
    officialName: "اللجنة العلمية جامعة 21 سبتمبر كلية الهندسة قسم الأجهزة الطبية المستوى الرابع",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "هندسة طبية",
    level: "رابع"
  },
  {
    link: "https://t.me/managementUSF",
    channelName: "اللجنة العلمية العاشرة",
    officialName: "اللجنة العلمية العاشرة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الهندسة والحاسوب",
    specialty: "إدارة طبية",
    level: "أول"
  },
  {
    link: "https://t.me/Research_methods_usf",
    channelName: "أساليب البحث",
    officialName: "أساليب البحث",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "ثالث"
  },
  {
    link: "https://t.me/forensic_medicine_usf",
    channelName: "الطب الشرعي",
    officialName: "الطب الشرعي",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "ثالث"
  },
  {
    link: "https://t.me/Medical_8_statistics",
    channelName: "إحصاء طبي",
    officialName: "إحصاء طبي",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "ثاني"
  },
  {
    link: "https://t.me/nUSF_9",
    channelName: "اللجنة العلمية التاسعة",
    officialName: "اللجنة العلمية التاسعة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "ثاني"
  },
  {
    link: "https://t.me/pharma8cology",
    channelName: "علم ادوية",
    officialName: "علم أدوية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "ثاني"
  },
  {
    link: "https://t.me/Social_8_Psychology",
    channelName: "علم نفس",
    officialName: "علم نفس",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "ثاني"
  },
  {
    link: "https://t.me/Hospital_8_accounting",
    channelName: "محاسبة منظمات",
    officialName: "محاسبة منظمات",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "ثاني"
  },
  {
    link: "https://t.me/organization_8_theory",
    channelName: "نظرية منظمة",
    officialName: "نظرية منظمة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "ثاني"
  },
  {
    link: "https://t.me/medical_7_administratio",
    channelName: "اللجنة العلمية إدارة طبية",
    officialName: "اللجنة العلمية إدارة طبية",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "إدارة طبية",
    level: "رابع"
  },
  {
    link: "https://t.me/AccountingUSP",
    channelName: "اللجنة العلمية كلية الإدارة قسم المحاسبة",
    officialName: "اللجنة العلمية كلية الإدارة قسم المحاسبة",
    university: "جامعة 21 سبتمبر",
    college: "كلية الإدارة الطبية",
    specialty: "محاسبة",
    level: "أول"
  }
];

export const colleges = [
  "كلية الطب والعلوم الصحية",
  "كلية طب الأسنان",
  "كلية الصيدلة السريرية",
  "كلية العلوم الطبية التطبيقية",
  "كلية الهندسة والحاسوب",
  "كلية التمريض العالي",
  "كلية الطب المخبري",
  "كلية الإدارة الطبية",
  "عمادة البيئة وخدمة المجتمع"
];

export const levels = ["أول", "ثاني", "ثالث", "رابع", "خامس"];

export const specialties: Record<string, string[]> = {
  "كلية الطب والعلوم الصحية": ["طب بشري"],
  "كلية طب الأسنان": ["طب الأسنان"],
  "كلية الصيدلة السريرية": ["صيدلة"],
  "كلية العلوم الطبية التطبيقية": ["مشترك"],
  "كلية الهندسة والحاسوب": ["IT", "آمن سيبراني", "هندسة طبية", "إدارة طبية", "كل التخصصات"],
  "كلية التمريض العالي": ["تمريض"],
  "كلية الطب المخبري": ["طب مخبري", "مختبرات"],
  "كلية الإدارة الطبية": ["إدارة طبية", "محاسبة"],
  "عمادة البيئة وخدمة المجتمع": ["غير مصنف"]
};
