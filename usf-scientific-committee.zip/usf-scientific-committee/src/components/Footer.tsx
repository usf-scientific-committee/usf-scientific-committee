'use client';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* عن اللجنة */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <div>
                <h3 className="text-xl font-bold">اللجنة العلمية المركزية</h3>
                <p className="text-blue-200 text-sm">جامعة 21 سبتمبر للعلوم الطبية والتطبيقية</p>
              </div>
            </div>
            <p className="text-blue-200 leading-relaxed">
              كيان طلابي علمي تطوعي يهدف إلى إيصال المعلومة بوضوح، توسيع مدارك الطالب، ومواكبة التطور التكنولوجي في مجال العلوم الطبية.
            </p>
          </div>

          {/* روابط سريعة */}
          <div>
            <h4 className="text-lg font-bold mb-4">روابط سريعة</h4>
            <ul className="space-y-2">
              <li><a href="/" className="text-blue-200 hover:text-white transition-colors">الرئيسية</a></li>
              <li><a href="/colleges" className="text-blue-200 hover:text-white transition-colors">بوابة الكليات</a></li>
              <li><a href="/library" className="text-blue-200 hover:text-white transition-colors">المكتبة الرقمية</a></li>
              <li><a href="/register" className="text-blue-200 hover:text-white transition-colors">تسجيل العضوية</a></li>
            </ul>
          </div>

          {/* تواصل معنا */}
          <div>
            <h4 className="text-lg font-bold mb-4">تواصل معنا</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <div>
                  <p className="text-blue-200 text-sm">للإنضمام والتواصل</p>
                  <p className="font-bold text-emerald-400" dir="ltr">774665526+</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-blue-700/50 mt-8 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-blue-300 text-sm">
              جميع الحقوق محفوظة للجنة العلمية المركزية - جامعة 21 سبتمبر
            </p>
            <p className="text-blue-300 text-sm flex items-center gap-2">
              <span>صُنع بـ</span>
              <svg className="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
              </svg>
              <span>لطلبة العلم والمعرفة</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
