'use client';

import { useState, ReactNode } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { channels, colleges, levels } from '@/data/channels';

export default function CollegesPage() {
  const [selectedCollege, setSelectedCollege] = useState<string | null>(null);
  const [expandedCollege, setExpandedCollege] = useState<string | null>(null);

  const filteredChannels = channels.filter(ch => {
    if (selectedCollege && ch.college !== selectedCollege) return false;
    return true;
  });

  const getChannelsForCollege = (college: string) => {
    return filteredChannels.filter(ch => ch.college === college);
  };

  const getLevelsForCollege = (college: string) => {
    const collegeChannels = getChannelsForCollege(college);
    return [...new Set(collegeChannels.map(ch => ch.level))];
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 lg:pt-32 pb-12 bg-gradient-to-br from-indigo-950 via-purple-950 to-indigo-950">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl lg:text-5xl font-bold text-white mb-4">بوابة الكليات</h1>
          <p className="text-amber-300 text-lg">اختر الكلية للوصول إلى القنوات العلمية</p>
        </div>
      </section>

      {/* College List */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {colleges.map((college) => {
              const collegeChannels = getChannelsForCollege(college);
              const isExpanded = expandedCollege === college;
              
              return (
                <div 
                  key={college} 
                  className="bg-white rounded-2xl shadow-lg overflow-hidden border border-slate-200 hover:shadow-xl transition-all duration-300"
                >
                  {/* College Header */}
                  <button
                    onClick={() => setExpandedCollege(isExpanded ? null : college)}
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-5 text-right flex items-center justify-between hover:from-indigo-700 hover:to-purple-700 transition-all"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                        <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                      </div>
                      <span className="text-white font-bold text-lg">{college}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="bg-white/20 text-white text-sm px-3 py-1 rounded-full">
                        {collegeChannels.length} قناة
                      </span>
                      <svg className={`w-6 h-6 text-white transition-transform ${isExpanded ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </button>

                  {/* Channel Links */}
                  {isExpanded && (
                    <div className="p-4 bg-slate-50">
                      {getLevelsForCollege(college).map((level) => {
                        const levelChannels = collegeChannels.filter(ch => ch.level === level);
                        
                        return (
                          <div key={level} className="mb-4 last:mb-0">
                            <h4 className="text-sm font-bold text-indigo-700 mb-2 flex items-center gap-2">
                              <span className="w-6 h-6 bg-indigo-100 rounded-full flex items-center justify-center text-xs">
                                {level}
                              </span>
                              المستوى {level}
                            </h4>
                            <div className="space-y-2">
                              {levelChannels.map((channel, index) => (
                                <a
                                  key={index}
                                  href={channel.link}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-3 bg-white rounded-lg p-3 hover:bg-emerald-50 hover:border-emerald-200 border border-slate-100 transition-all group"
                                >
                                  <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                                    <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                    </svg>
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <h5 className="font-bold text-slate-800 group-hover:text-emerald-600 transition-colors">
                                      {channel.officialName}
                                    </h5>
                                    <p className="text-xs text-slate-500">{channel.specialty}</p>
                                  </div>
                                  <svg className="w-5 h-5 text-emerald-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                  </svg>
                                </a>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                      
                      {collegeChannels.length === 0 && (
                        <div className="text-center py-8">
                          <p className="text-slate-500">لا توجد قنوات لهذه الكلية</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {colleges.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-12 h-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-slate-700 mb-2">لا توجد كليات</h3>
              <p className="text-slate-500">لم يتم إضافة كليات بعد</p>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}