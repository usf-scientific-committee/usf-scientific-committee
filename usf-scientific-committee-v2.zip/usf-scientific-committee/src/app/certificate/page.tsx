'use client';

import { useState } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { storage } from '@/data/types';

const colleges = [
  'كلية الطب البشري',
  'كلية طب الأسنان',
  'كلية الصيدلة السريرية',
  'كلية العلوم الطبية والتطبيقية',
  'كلية الهندسة والحاسوب',
  'كلية التمريض العالي',
  'كلية الطب المخبري',
  'كلية الإدارة الطبية',
  'عمادة البيئة وخدمة المجتمع'
];

const levels = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس'];

const certificateTypes = [
  { value: 'membership', label: 'شهادة عضوية اللجنة العلمية' },
  { value: 'volunteer', label: 'شهادة مشاركة تطوعية' },
  { value: 'training', label: 'شهادة حضور تدريب' },
  { value: 'appreciation', label: 'شهادة تقدير' },
  { value: 'committee_work', label: 'شهادة عمل في اللجنة' }
];

export default function CertificatePage() {
  const [formData, setFormData] = useState({
    fullName: '',
    college: '',
    level: '',
    specialty: '',
    email: '',
    phone: '',
    certificateType: '',
    purpose: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'الرجاء إدخال الاسم الرباعي الكامل';
    }

    if (!formData.college) {
      newErrors.college = 'الرجاء اختيار الكلية';
    }

    if (!formData.level) {
      newErrors.level = 'الرجاء اختيار المستوى';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'الرجاء إدخال البريد الإلكتروني';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'الرجاء إدخال بريد إلكتروني صحيح';
    }

    if (!formData.certificateType) {
      newErrors.certificateType = 'الرجاء اختيار نوع الشهادة';
    }

    if (!formData.purpose.trim()) {
      newErrors.purpose = 'الرجاء كتابة سبب طلب الشهادة';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const certificate = {
        id: `cert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        fullName: formData.fullName.trim(),
        college: formData.college,
        level: formData.level,
        specialty: formData.specialty || '',
        email: formData.email.trim().toLowerCase(),
        phone: formData.phone || '',
        certificateType: formData.certificateType,
        purpose: formData.purpose.trim(),
        requestDate: new Date().toISOString(),
        status: 'pending' as const
      };

      storage.addCertificate(certificate);

      setSubmitStatus('success');
      setFormData({
        fullName: '',
        college: '',
        level: '',
        specialty: '',
        email: '',
        phone: '',
        certificateType: '',
        purpose: ''
      });

      setTimeout(() => setSubmitStatus('idle'), 5000);
    } catch (error) {
      setSubmitStatus('error');
      setTimeout(() => setSubmitStatus('idle'), 5000);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900" dir="rtl">
      <Navigation />

      {/* Header Section */}
      <section className="relative py-16 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-amber-500/10 to-transparent" />
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />
        
        <div className="relative max-w-4xl mx-auto text-center z-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl mb-6 shadow-xl shadow-amber-500/20">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
            </svg>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            طلب شهادة إلكترونية
          </h1>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            يمكنك الآن طلب الشهادات الإلكترونية من اللجنة العلمية المركزية بسهولة
          </p>
        </div>
      </section>

      {/* Form Section */}
      <section className="flex-1 py-12 px-4">
        <div className="max-w-2xl mx-auto">
          {/* Success Message */}
          {submitStatus === 'success' && (
            <div className="mb-8 p-6 bg-green-500/20 border border-green-500/50 rounded-2xl backdrop-blur-sm">
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-green-400">تم إرسال طلبك بنجاح!</h3>
                  <p className="text-slate-300">سيتم مراجعة طلبك وإرسال الشهادة إلى بريدك الإلكتروني خلال 24-48 ساعة</p>
                </div>
              </div>
            </div>
          )}

          {/* Error Message */}
          {submitStatus === 'error' && (
            <div className="mb-8 p-6 bg-red-500/20 border border-red-500/50 rounded-2xl backdrop-blur-sm">
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-red-400">حدث خطأ!</h3>
                  <p className="text-slate-300">الرجاء المحاولة مرة أخرى أو التواصل معنا</p>
                </div>
              </div>
            </div>
          )}

          {/* Form Card */}
          <div className="bg-slate-800/50 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* الاسم الكامل */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  الاسم الرباعي الكامل <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="أدخل اسمك الرباعي كما هو مدون في السجلات"
                  className={`w-full px-5 py-4 bg-slate-900/50 border ${errors.fullName ? 'border-red-500' : 'border-slate-600'} rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all`}
                />
                {errors.fullName && (
                  <p className="mt-2 text-sm text-red-400">{errors.fullName}</p>
                )}
              </div>

              {/* الكلية والمستوى */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    الكلية <span className="text-red-400">*</span>
                  </label>
                  <select
                    name="college"
                    value={formData.college}
                    onChange={handleChange}
                    className={`w-full px-5 py-4 bg-slate-900/50 border ${errors.college ? 'border-red-500' : 'border-slate-600'} rounded-xl text-white focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all appearance-none cursor-pointer`}
                  >
                    <option value="">اختر الكلية</option>
                    {colleges.map(college => (
                      <option key={college} value={college}>{college}</option>
                    ))}
                  </select>
                  {errors.college && (
                    <p className="mt-2 text-sm text-red-400">{errors.college}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    المستوى <span className="text-red-400">*</span>
                  </label>
                  <select
                    name="level"
                    value={formData.level}
                    onChange={handleChange}
                    className={`w-full px-5 py-4 bg-slate-900/50 border ${errors.level ? 'border-red-500' : 'border-slate-600'} rounded-xl text-white focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all appearance-none cursor-pointer`}
                  >
                    <option value="">اختر المستوى</option>
                    {levels.map(level => (
                      <option key={level} value={level}>{level}</option>
                    ))}
                  </select>
                  {errors.level && (
                    <p className="mt-2 text-sm text-red-400">{errors.level}</p>
                  )}
                </div>
              </div>

              {/* التخصص والبريد الإلكتروني */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    التخصص <span className="text-slate-500">(اختياري)</span>
                  </label>
                  <input
                    type="text"
                    name="specialty"
                    value={formData.specialty}
                    onChange={handleChange}
                    placeholder="أدخل التخصص إن وجد"
                    className="w-full px-5 py-4 bg-slate-900/50 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    البريد الإلكتروني <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="example@email.com"
                    className={`w-full px-5 py-4 bg-slate-900/50 border ${errors.email ? 'border-red-500' : 'border-slate-600'} rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all`}
                  />
                  {errors.email && (
                    <p className="mt-2 text-sm text-red-400">{errors.email}</p>
                  )}
                </div>
              </div>

              {/* رقم الهاتف ونوع الشهادة */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    رقم الهاتف <span className="text-slate-500">(اختياري)</span>
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="07XXXXXXXXX"
                    className="w-full px-5 py-4 bg-slate-900/50 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    نوع الشهادة <span className="text-red-400">*</span>
                  </label>
                  <select
                    name="certificateType"
                    value={formData.certificateType}
                    onChange={handleChange}
                    className={`w-full px-5 py-4 bg-slate-900/50 border ${errors.certificateType ? 'border-red-500' : 'border-slate-600'} rounded-xl text-white focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all appearance-none cursor-pointer`}
                  >
                    <option value="">اختر نوع الشهادة</option>
                    {certificateTypes.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                  {errors.certificateType && (
                    <p className="mt-2 text-sm text-red-400">{errors.certificateType}</p>
                  )}
                </div>
              </div>

              {/* سبب طلب الشهادة */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  سبب طلب الشهادة <span className="text-red-400">*</span>
                </label>
                <textarea
                  name="purpose"
                  value={formData.purpose}
                  onChange={handleChange}
                  rows={4}
                  placeholder="اكتب سبب طلب الشهادة بالتفصيل (مثال: للتوظيف، للتقديم للمنح، للترقي الوظيفي...)"
                  className={`w-full px-5 py-4 bg-slate-900/50 border ${errors.purpose ? 'border-red-500' : 'border-slate-600'} rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none`}
                />
                {errors.purpose && (
                  <p className="mt-2 text-sm text-red-400">{errors.purpose}</p>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 to-orange-600 text-white font-bold text-lg rounded-xl hover:from-amber-600 hover:to-orange-700 focus:outline-none focus:ring-4 focus:ring-amber-500/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-amber-500/25"
              >
                {isSubmitting ? (
                  <span className="flex items-center justify-center gap-3">
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    جاري الإرسال...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                    إرسال طلب الشهادة
                  </span>
                )}
              </button>
            </form>

            {/* Info Box */}
            <div className="mt-8 p-5 bg-slate-900/50 rounded-xl border border-slate-700/50">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-amber-400 mb-1">ملاحظة مهمة</h4>
                  <p className="text-sm text-slate-400">
                    سيتم إرسال الشهادة بصيغة إلكترونية (PDF) إلى بريدك الإلكتروني خلال 24-48 ساعة من لحظة مراجعة الطلب.
                    تأكد من صحة بريدك الإلكتروني المدخل.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}