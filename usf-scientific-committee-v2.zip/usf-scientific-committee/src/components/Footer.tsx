'use client';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-r from-indigo-950 via-purple-950 to-indigo-950 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <p className="text-amber-300 text-sm">
            جميع الحقوق محفوظة للجنة العلمية المركزية - ملتقى الطالب الجامعي - جامعة 21 سبتمبر
          </p>
        </div>
      </div>
    </footer>
  );
}